import HeroSection from "../component/HeroSection";

 const page = ()=>{
return(
    <HeroSection
    HeroSectionHead={"Case Study Analysis"}
    HeroSectionPara={"Unlocking insights, perfecting excellence—your go-to for polished content. Dive into our enriching case study experience!"}
    HeroSectionButton={"Join us"}

  />

)
}
export default page;