
const Motion = ()=>{
  
    return( 
 
           <div  className={`transition-opacity duration-500 ? 'opacity-100' : 'opacity-0'`}>
            
        </div>
    )
    }
    export default Motion 