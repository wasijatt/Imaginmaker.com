const Web = ()=>{
  
    return( 
        <div className="bg-black">
                ddfgb
    
        </div>
    )
    }
    export default Web 