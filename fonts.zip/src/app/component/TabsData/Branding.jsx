const Branding = ()=>{
  
    return( 
        <div className="bg-black">
                ddfgb
    
        </div>
    )
    }
    export default Branding 