const Ui = ()=>{
  
    return( 
        <div className="bg-white ">
                ddfgb
    
        </div>
    )
    }
    export default Ui 